# FFmpeg 安装指南

## 什么是 FFmpeg？

FFmpeg 是一个开源的跨平台音视频处理工具，它可以用于音频和视频的编码、解码、转码、混流、分离、过滤等操作。在我们的多模态输入功能中，FFmpeg 用于处理音频文件的转换，确保音频格式符合语音识别 API 的要求。

## Windows 安装步骤

### 方法一：使用官方下载（推荐）

1. 访问 FFmpeg 官方网站的下载页面：[https://ffmpeg.org/download.html](https://ffmpeg.org/download.html)

2. 在 Windows 部分，点击 "Windows builds from gyan.dev" 或其他提供的 Windows 构建链接

3. 下载 "ffmpeg-release-full" 版本（包含所有组件）

4. 解压下载的压缩包到一个固定位置，例如 `C:\ffmpeg`

5. 添加 FFmpeg 到系统环境变量：
   - 右键点击 "此电脑" 或 "我的电脑"，选择 "属性"
   - 点击 "高级系统设置"
   - 点击 "环境变量" 按钮
   - 在 "系统变量" 部分，找到并选择 "Path" 变量，然后点击 "编辑"
   - 点击 "新建" 按钮，添加 FFmpeg 的 bin 目录路径，例如 `C:\ffmpeg\bin`
   - 点击 "确定" 保存所有更改

6. 重启命令提示符或 PowerShell 窗口

7. 验证安装：在命令提示符或 PowerShell 中输入 `ffmpeg -version`，应该显示 FFmpeg 的版本信息

### 方法二：使用 Chocolatey 包管理器

如果您已经安装了 Chocolatey 包管理器，可以使用以下命令安装 FFmpeg：

```powershell
choco install ffmpeg
```

### 方法三：使用 Scoop 包管理器

如果您使用 Scoop 包管理器，可以使用以下命令安装 FFmpeg：

```powershell
scoop install ffmpeg
```

## macOS 安装步骤

### 使用 Homebrew 安装

1. 如果尚未安装 Homebrew，请先安装：

```bash
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```

2. 使用 Homebrew 安装 FFmpeg：

```bash
brew install ffmpeg
```

## Linux 安装步骤

### Ubuntu/Debian

```bash
sudo apt update
sudo apt install ffmpeg
```

### CentOS/RHEL

```bash
sudo yum install epel-release
sudo yum install ffmpeg ffmpeg-devel
```

### Fedora

```bash
sudo dnf install ffmpeg
```

### Arch Linux

```bash
sudo pacman -S ffmpeg
```

## 验证安装

安装完成后，在终端或命令提示符中运行以下命令验证 FFmpeg 是否正确安装：

```bash
ffmpeg -version
```

如果显示 FFmpeg 的版本信息，则表示安装成功。

## 安装后的操作

1. 重启多模态服务器（如果正在运行）
2. 重新测试语音识别和图像识别功能

## 常见问题

### 安装后仍然提示找不到 FFmpeg

- 确保您已经将 FFmpeg 的 bin 目录添加到系统环境变量 PATH 中
- 重启计算机，确保环境变量更改生效
- 在新的命令提示符或终端窗口中验证 FFmpeg 是否可用

### 权限问题

- Windows：以管理员身份运行命令提示符或 PowerShell
- Linux/macOS：使用 sudo 运行安装命令

### 其他问题

如果您遇到其他问题，请参考 FFmpeg 官方文档或在线社区寻求帮助。